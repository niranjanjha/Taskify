import React from 'react'

const CompletePage = () => {
  return (
    <div>
      azsxdvgb
    </div>
  )
}

export default CompletePage
