import React from 'react'

const PendingPage = () => {
  return (
    <div>
      sdfgh
    </div>
  )
}

export default PendingPage
