import { EyeOff, LogIn, Eye, Mail, Lock } from 'lucide-react'
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify'
import axios from 'axios';

// The original file was missing, so we define these classes directly here.
const BUTTON_CLASSES = 'flex items-center justify-center space-x-2 py-3 px-6 rounded-full text-white font-semibold transition-transform duration-200 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-purple-300 bg-gradient-to-r from-purple-500 to-fuchsia-500 shadow-lg';
const INPUTWRAPPER = 'flex items-center space-x-3 p-3 bg-gray-50 border border-gray-200 rounded-full focus-within:ring-2 focus-within:ring-purple-200 transition-shadow';

// This data was likely in the missing file, so we define it here.
const fields = [
    {
        name: "email",
        type: "email",
        placeholder: "Email",
        icon: Mail,
    },
    {
        name: "password",
        type: "password",
        placeholder: "Password",
        icon: Lock,
        isPassword: true,
    },
];

const INITIAL_FORM = { email: "", password: "" }

const Login = ({ onSubmit, onSwitchMode }) => {
    const [showPassword, setShowPassword] = useState(false)
    const [loading, setLoading] = useState(false)
    const [formData, setFormData] = useState(INITIAL_FORM)
    const [rememberMe, setRememberMe] = useState(false)
    const navigate = useNavigate()
    const url = "http://localhost:4000"

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!rememberMe) {
            toast.error('You must enable "Remember Me" to login. ')
            return
        }
        setLoading(true)
        try {
            const { data } = await axios.post(`${url}/api/user/login`, formData)
            if (!data.token) throw new Error(data.message || "Login Failed")
            localStorage.setItem("token", data.token)
            localStorage.setItem("userId", data.user.id)
            setFormData(INITIAL_FORM)
            onSubmit?.({ token: data.token, userId: data.user.id, ...data.user })
            toast.success("Login successful! Redirecting...")
            setTimeout(() => navigate("/"), 1000)
        } catch (err) {
            const msg = err.response?.data?.message || err.message
            toast.error(msg)
        }
        finally {
            setLoading(false)
        }
    }


    const handleSwitchMode = () => {
        toast.dismiss()
        onSwitchMode?.()
    }


    return (
        <>
            {/* The CSS for react-toastify needs to be loaded from a CDN as it's not a direct import */}
            <link rel="stylesheet" href="https://unpkg.com/react-toastify@8.2.0/dist/ReactToastify.min.css" />
            <div className='max-w-md bg-white w-full shadow-lg border border-purple-100 rounded-xl p-8'>
                <ToastContainer position='top-center' autoClose={3000} hideProgressBar />
                <div className='mb-6 text-center'>
                    <div className='w-16 h-16 bg-gradient-to-br from-fuchsia-500 to-purple-600 rounded-full
                    mx-auto flex items-center justify-center mb-4'>
                        <LogIn className='w-8 h-8 text-white' />
                    </div>
                    <h2 className='text-2xl font-bold text-gray-800'>Welcome Back</h2>
                    <p className='text-gray-500 text-sm mt-1'>Sign in to continue to TaskFlow</p>
                </div>
                <form onSubmit={handleSubmit} className='space-y-4'>
                    {fields.map(({ name, type, placeholder, icon: Icon, isPassword }) => (
                        <div key={name} className={INPUTWRAPPER}>
                            <Icon className='text-purple-500 w-5 h-5' />
                            <input
                                type={isPassword && showPassword ? "text" : type}
                                placeholder={placeholder}
                                value={formData[name]}
                                onChange={(e) => setFormData({ ...formData, [name]: e.target.value })}
                                className='w-full focus:outline-none text-sm text-gray-700'
                                required
                            />
                            {isPassword && (
                                <button type='button' onClick={() => setShowPassword((prev) => !prev)}
                                    className='ml-2 text-gray-500 hover:text-purple-500
                                    transition-colors'>
                                    {showPassword ? <EyeOff className='w-5 h-5' /> : <Eye className='h-5 w-5' />}
                                </button>
                            )}
                        </div>
                    ))}

                    <div className='flex items-center justify-between mt-4'>
                        <div className='flex items-center'>
                            <input type="checkbox" id='rememberMe' checked={rememberMe}
                                onChange={() => setRememberMe(!rememberMe)}
                                className='h-4 w-4 text-purple-500 focus:ring-purple-400
                                border-gray-300 rounded' />
                            <label htmlFor='rememberMe'
                                className='ml-2 block text-sm text-gray-700'>
                                Remember Me
                            </label>
                        </div>
                    </div>

                    <button type='submit' className={`${BUTTON_CLASSES} w-full`}
                        disabled={loading}>
                        {loading ? (
                            "Logging in..."
                        ) : (
                            <>
                                <LogIn className='w-4 h-4' />
                                Login
                            </>
                        )}
                    </button>
                </form>
                <p className='text-center text-sm text-gray-600 mt-6'>
                    Don't have an account?{' '}
                    <button type='button' className='text-purple-600 hover:
                    text-purple-700 hover:underline
                    font-medium transition-colors' onClick={handleSwitchMode}>
                        Sign Up
                    </button>
                </p>
            </div>
        </>
    )
}

export default Login
