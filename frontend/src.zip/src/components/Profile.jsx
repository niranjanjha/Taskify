import React from "react";
import { toast, ToastContainer } from "react-toastify";
import { BACK_BUTTON } from "../assets/dummy";
import { ChevronLeft } from "lucide-react";

const API_URL='http://localhost:4000'
const Profile = () => {
  return(
  <div className=" min-h-screen bg-gray-50">
    <ToastContainer position="top-center" autoClose={3000} />
    <div className="max-w-4x1 mx-auto p-6">
      <button onClick={() => navigate(-1)} className={BACK_BUTTON}>
        <Chevron Left className=" w-5 h-5 mr-1" />
        Back to Dashboard
      </button>{" "}
      I
      <div className=" flex items-center gap-4 mb-8">
        <div
          className=" w-16 h-16 rounded-full bg-gradient-to-br from-fuchsia-500 to-purple-600
flex items-center justify-center Itext-white text-2x1 font-bold shadow-md"
        ></div>
      </div>
    </div>
  </div>;
)};

export default Profile;
