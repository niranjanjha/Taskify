import jwt from 'jsonwebtoken'
import User from '../models/userModel.js'

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret_here'

export default async function authMiddleware(req, res, next) {
  // GRAB THE BEARER TOKEN FROM AUTHORIZATION HEADER
  const authHeader = req.headers.authorization

  console.log("Auth header received:", authHeader)


  if (!authHeader || !authHeader.startsWith('Bearer')) {
    return res
      .status(401)
      .json({ success: false, message: "Not Authorized, Token Missing" })
  }

  // Extract token after "Bearer"
  const token = authHeader.split(' ')[1]

  try {
    // VERIFY AND ATTACH USER OBJECT
    const payload = jwt.verify(token, JWT_SECRET)
    const user = await User.findById(payload.id).select('-password')

    if (!user) {
      return res.status(401).json({ success: false, message: "User not found" })
    }

    req.user = user
    next()
  } catch (err) {
    console.log("JWT verification failed", err)
    return res
      .status(401)
      .json({ success: false, message: "Token Invalid or Expired" })
  }
}
