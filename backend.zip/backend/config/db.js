import mongoose from "mongoose";



export const connectDB= async ()=>{
    await mongoose.connect('mongodb+srv://shubhamjha4830:shubhamjha4830@cluster0.qgcyns1.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0/Taskify')
    .then(()=>console.log('DB connected'));
}